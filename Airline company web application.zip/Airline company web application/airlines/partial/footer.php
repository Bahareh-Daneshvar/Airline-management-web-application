<footer>
    <div class="footerlink">
        <p class="lf">Copyright &copy; 2010 <a href="#">Domain Name</a> - All Rights Reserved</p>
        <p class="rf">Design by <a href="http://www.templatemonster.com/">Bahare</a></p>
        <div style="clear:both;"></div>
    </div>
</footer>