<header style="height: 130px">
    <div class="wrapper" >
        <h1><a href="index.html" id="logo">AirLines</a><span id="slogan">International Travel</span></h1>
        <div class="right">
            <nav>
                <ul id="top_nav">
                    <?php
                    if (isset($_SESSION["username"])) {
                        echo "<li style=\"color:darkgoldenrod;\">Welcome {$_SESSION["username"]}<a href=\"logout.php\">Logout</a></li>";
                    }
                    ?>
                </ul>
            </nav>
            <nav >
                <ul id="menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="login.php">Login/Register</a></li>
                    <li ><a href="contacts.php">Contacts</a></li>
                    <li ><a href="passengerreport.php">Passsenger Report</a></li>
                    <?php
                    if (isset($_SESSION["userType"]) && $_SESSION["userType"] == "admin"){
                        echo " <li ><a href=\"airplane.php\">airplane</a></li>
                    <li ><a href=\"pilot.php\">pilot</a></li>
                    <li ><a href=\"trip.php\">trip</a></li>
                    <li ><a href=\"crew.php\">crew</a></li>
                    <li ><a href=\"report.php\">report</a></li>";

                    }
                    ?>

                </ul>
            </nav>
        </div>
    </div>
</header>