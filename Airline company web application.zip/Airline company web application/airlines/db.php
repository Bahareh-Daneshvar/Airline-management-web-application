<?php
class Database{
    private $host  = 'localhost';
    private $user  = 'root';
    private $password   = "";
    private $database  = "airplanecompanydb";
    public  $connection;

    public function getConnection(){
        try {
            $conn = new mysqli($this->host, $this->user, $this->password, $this->database);
            if ($conn->connect_error) {
                die("Error failed to connect to MySQL: " . $conn->connect_error);
                $this->connection = null;
                return null;
            } else {
                mysqli_query($conn, "SET NAMES 'utf8'");
                $this->connection = $conn;
                return $this->connection;
            }
        }
        catch(mysqli_sql_exception $ex)
        {
            $this->connection = null;
            return null;
        }
    }
}