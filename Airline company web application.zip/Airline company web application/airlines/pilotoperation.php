<?php
session_start();
include "db.php";

if (isset($_POST["btnAdd"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $id= $_POST["txtPID"];
    $surname= $_POST["txtSurName"];
    $name= $_POST["txtName"];
    $phone= $_POST["txtPhone"];
    $salary= $_POST["txtSalary"];
    $address= $_POST["txtAddress"];
    $airplanes= $_POST["txtAirplanes"];
    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("insert into pilot(surname,name,phone,salary,address,airplanes) values (?,?,?,?,?,?)");
    $stmt->bind_param("sssdss",$surname,$name,$phone,$salary,$address,$airplanes);
    $stmt->execute();
    $_SESSION["message"] = "Added Data Successfully";
    echo "<script>window.location.href = 'pilot.php';</script>";
}
if (isset($_POST["btnEdit"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $id= $_POST["txtPID"];
    $surname= $_POST["txtSurName"];
    $name= $_POST["txtName"];
    $phone= $_POST["txtPhone"];
    $salary= $_POST["txtSalary"];
    $address= $_POST["txtAddress"];
    $airplanes= $_POST["txtAirplanes"];

    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("update pilot set surname=?,name=?,phone=?,salary=?,address=?,airplanes=? where pid = ?");
    $stmt->bind_param("sssdssd",$surname,$name,$phone,$salary,$address,$airplanes,$id);
    $stmt->execute();
    $_SESSION["message"] = "Update Data Successfully";
    echo "<script>window.location.href = 'pilot.php';</script>";
}
if (isset($_POST["btnDelete"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $id = $_POST["txtID"];
    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("delete from pilot where pid = ?");
    $stmt->bind_param("d",$id);
    $stmt->execute();
    $_SESSION["message"] = "Delete Data Successfully";
    echo "<script>window.location.href = 'pilot.php';</script>";
}
?>