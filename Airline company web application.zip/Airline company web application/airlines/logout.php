<?php
session_start();
unset($_SESSION["username"]);
unset($_SESSION["userType"]);
unset($_SESSION["id"]);

echo "<script>window.location.href = 'login.php';</script>";