<?php
session_start();
include "db.php";
$message= "";
$model= "";
$id = -1;
$buildNumber = 0 ;
if (isset($_SESSION["message"])) {
    $message = $_SESSION["message"];
    $_SESSION["message"]="";

}
if (isset($_GET["id"])){
    $db = new Database();
    $conn= $db->getConnection();
    $date = new DateTime();
    $id  =$_GET["id"];
    $stmt = $conn->prepare("SELECT * FROM airplane where numser = ? ");
    $stmt->bind_param("d",$id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $model = $row["model"];
    $buildNumber = $row["buildnumber"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>AirPlane</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all">
    <script type="text/javascript" src="js/jquery-1.4.2.js" ></script>
    <script type="text/javascript" src="js/cufon-yui.js"></script>
    <script type="text/javascript" src="js/cufon-replace.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_italic_600.font.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_italic_400.font.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/ie6_script_other.js"></script>
    <script type="text/javascript" src="js/html5.js"></script>
    <![endif]-->
</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="body1">
    <div class="main">
        <?php
        require_once  "partial/header.php";
        ?>
    </div>
</div>
<div class="main">
    <div id="banner">
        <div class="text1"> COMFORT<span>Guaranteed</span>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
        <a href="#" class="button_top">Order Tickets Online</a></div>
</div>
<div class="main">
    <section id="content">
        <article class="col1">
            <div class="pad_1">
                <h2>Information Form</h2>
                <form id="form_1" action="airoperation.php" method="post">
                    <div class="wrapper"> ID:
                        <div class="bg">
                            <input type="text" name="txtID" readonly class="input input1" value="<?php echo $id; ?>" onBlur="if(this.value=='') this.value='Enter BuildNumber'" onFocus="if(this.value =='Enter BuildNumber' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> BuildNumber:
                        <div class="bg">
                            <input type="text" name="txtBuildNumber" class="input input1" value="<?php echo $buildNumber; ?>" onBlur="if(this.value=='') this.value='Enter BuildNumber'" onFocus="if(this.value =='Enter BuildNumber' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> Model:
                        <div class="bg">
                            <input type="text" name="txtModel" class="input input1" value="<?php echo $model; ?>" onBlur="if(this.value=='') this.value='Enter Model'" onFocus="if(this.value =='Enter Model' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper">
                        <div class="bg left">
                            <input type="submit" name="btnAdd" class="button2" value="Add" />
                            <input type="submit" name="btnEdit" class="button2" value="Edit" />
                        </div>
                        <input type="submit"  style="width: 100%" name="btnDelete" class="button2" value="Delete" />

                    </div>
                    <p> <?php echo $message; ?> </p>

                </form>
            </div>
        </article>
        <article class="col2 pad_left1">
            <h2>Information Form</h2>
            <form id="form_2" action="#" method="post">
                <div class="marker">
                    <div class="wrapper">
                        <p class="pad_bot2"><strong>All Airplane</strong></p>
                        <p class="pad_bot2">
                        <table>
                            <tr>
                                <td>
                                    NumSer
                                </td>
                                <td>
                                    BuildNumber
                                </td>
                                <td>
                                    Model
                                </td>
                                <td>
                                    Select
                                </td>
                            </tr>
                            <?php
                            $db = new Database();
                            $conn= $db->getConnection();
                            $date = new DateTime();
                            $stmt = $conn->prepare("SELECT * FROM airplane ");
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $color = 0 ;
                            while ($row = $result->fetch_assoc()){
                                if (isset($_GET["id"])){$color=$_GET["id"];}
                                if ($color == $row["numser"]){
                                    $buildNumber = $row["buildnumber"];
                                    $model = $row["model"];
                                    echo "<tr style='background: red;'>
                    <td class=\"text-center\">{$row["numser"]}<br /></td>
                    <td class=\"text-center\">{$row["buildnumber"]}<br /></td>
                    <td class=\"text-center\">{$row["model"]}<br /></td>
                    <td class=\"text-right\"><a href='airplane.php?id={$row["numser"]}'>Select</a> </td>
                  </tr>";
                                }
                                else {
                                    echo "<tr>
                    <td class=\"text-center\">{$row["numser"]}<br /></td>
                    <td class=\"text-center\">{$row["buildnumber"]}<br /></td>
                    <td class=\"text-center\">{$row["model"]}<br /></td>
                    <td class=\"text-right\"><a href='airplane.php?id={$row["numser"]}'>Select</a> </td>
                  </tr>";
                                }

                            }
                            ?>
                        </table>
                    </div>

                </div>
            </form>
        </article>
    </section>
</div>
<div class="body2">
    <div class="main">
        <?php
        require_once  "partial/footer.php";
        ?>
    </div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>