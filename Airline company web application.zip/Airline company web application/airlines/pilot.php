<?php
session_start();
include "db.php";
$message= "";
$id = -1;
$surname= "";
$name = "" ;
$phone = 0;
$address = "";
$salary = 0 ;
$airplanes = "";
if (isset($_SESSION["message"])) {
    $message = $_SESSION["message"];
    $_SESSION["message"]="";

}
if (isset($_GET["id"])){
    $db = new Database();
    $conn= $db->getConnection();
    $date = new DateTime();
    $id  =$_GET["id"];
    $stmt = $conn->prepare("SELECT * FROM pilot where pid = ? ");
    $stmt->bind_param("d",$id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $surname = $row["surname"];
    $name = $row["name"];
    $phone = $row["phone"];
    $address = $row["address"];
    $salary = $row["salary"];
    $airplanes = $row["airplanes"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Pilot</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all">
    <script type="text/javascript" src="js/jquery-1.4.2.js" ></script>
    <script type="text/javascript" src="js/cufon-yui.js"></script>
    <script type="text/javascript" src="js/cufon-replace.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_italic_600.font.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_italic_400.font.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/ie6_script_other.js"></script>
    <script type="text/javascript" src="js/html5.js"></script>
    <![endif]-->
</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="body1">
    <div class="main">
        <?php
        require_once  "partial/header.php";
        ?>
    </div>
</div>
<div class="main">
    <div id="banner">
        <div class="text1"> COMFORT<span>Guaranteed</span>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
        <a href="#" class="button_top">Order Tickets Online</a></div>
</div>
<div class="main">
    <section id="content">
        <article class="col1">
            <div class="pad_1">
                <h2>Information Form</h2>
                <form id="form_1" action="pilotoperation.php" method="post">
                    <div class="wrapper"> PID:
                        <div class="bg">
                            <input type="text" name="txtPID" class="input input1" value="<?php echo $id; ?>" onBlur="if(this.value=='') this.value='Enter SurName'" onFocus="if(this.value =='Enter SurName' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> SurName:
                        <div class="bg">
                            <input type="text" name="txtSurName" class="input input1" value="<?php echo $surname; ?>" onBlur="if(this.value=='') this.value='Enter SurName'" onFocus="if(this.value =='Enter SurName' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> Name:
                        <div class="bg">
                            <input type="text" name="txtName" class="input input1" value="<?php echo $name; ?>" onBlur="if(this.value=='') this.value='Enter Name'" onFocus="if(this.value =='Enter Name' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> Phone:
                        <div class="bg">
                            <input type="text" name="txtPhone" class="input input1" value="<?php echo $phone; ?>" onBlur="if(this.value=='') this.value='Enter Phone'" onFocus="if(this.value =='Enter Phone' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> Salary:
                        <div class="bg">
                            <input type="text" name="txtSalary" class="input input1" value="<?php echo $salary; ?>" onBlur="if(this.value=='') this.value='Enter Salary'" onFocus="if(this.value =='Enter Salary' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> Address:
                        <div class="bg">
                            <input type="text" name="txtAddress" class="input input1" value="<?php echo $address; ?>" onBlur="if(this.value=='') this.value='Enter Address'" onFocus="if(this.value =='Enter Address' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> AirPlanes:
                        <div class="bg">
                            <input type="text" name="txtAirplanes" class="input input1" value="<?php echo $airplanes; ?>" onBlur="if(this.value=='') this.value='Enter Phone'" onFocus="if(this.value =='Enter Phone' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper">
                        <div class="bg left">
                            <input type="submit" name="btnAdd" class="button2" value="Add" />
                            <input type="submit" name="btnEdit" class="button2" value="Edit" />

                        </div>
                        <input type="submit" style="width: 100%" name="btnDelete" class="button2" value="Delete" />

                    </div>
                    <p><?php echo $message; ?></p>

                </form>
            </div>
        </article>
        <article class="col2 pad_left1">
            <h2>Information Form</h2>
            <form id="form_2" action="#" method="post">
                <div class="marker">
                    <div class="wrapper">
                        <p class="pad_bot2"><strong>All Pilot Information</strong></p>
                        <p class="pad_bot2">
                        <table>
                            <tr>
                                <td>
                                    PID
                                </td>
                                <td>
                                    SurName
                                </td>
                                <td>
                                    Name
                                </td>
                                <td>
                                    Phone
                                </td>
                                <td>
                                    Address
                                </td>
                                <td>
                                    Salary
                                </td>
                                <td>
                                    AirPlans
                                </td>
                                <td>
                                    Operations
                                </td>
                            </tr>
                            <?php
                            $db = new Database();
                            $conn= $db->getConnection();
                            $date = new DateTime();
                            $stmt = $conn->prepare("SELECT * FROM pilot ");
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $color = 0 ;
                            while ($row = $result->fetch_assoc()){
                                if (isset($_GET["id"])){$color=$_GET["id"];}
                                if ($color == $row["pid"]){
                                    echo "<tr style='background: red;'>
                    <td class=\"text-center\">{$row["pid"]}<br /></td>
                    <td class=\"text-center\">{$row["surname"]}<br /></td>
                    <td class=\"text-center\">{$row["name"]}<br /></td>
                    <td class=\"text-center\">{$row["phone"]}<br /></td>
                    <td class=\"text-center\">{$row["address"]}<br /></td>
                    <td class=\"text-center\">{$row["salary"]}<br /></td>
                    <td class=\"text-center\">{$row["airplanes"]}<br /></td>
                    <td class=\"text-right\"><a href='pilot.php?id={$row["pid"]}'>Select</a> </td>
                  </tr>";
                                }
                                else {
                                    echo "<tr>
                    <td class=\"text-center\">{$row["pid"]}<br /></td>
                    <td class=\"text-center\">{$row["surname"]}<br /></td>
                    <td class=\"text-center\">{$row["name"]}<br /></td>
                    <td class=\"text-center\">{$row["phone"]}<br /></td>
                    <td class=\"text-center\">{$row["address"]}<br /></td>
                    <td class=\"text-center\">{$row["salary"]}<br /></td>
                    <td class=\"text-center\">{$row["airplanes"]}<br /></td>
                    <td class=\"text-right\"><a href='pilot.php?id={$row["pid"]}'>Select</a> </td>
                  </tr>";
                                }

                            }
                            ?>
                        </table>
                    </div>

                </div>
            </form>
        </article>
    </section>
</div>
<div class="body2">
    <div class="main">
        <?php
        require_once  "partial/footer.php";
        ?>
    </div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>