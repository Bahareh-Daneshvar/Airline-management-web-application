<?php
session_start();
include "db.php";
$message= "";
$messageReg="";
if (isset($_SESSION["message"])) {
    $message = $_SESSION["message"];
    $_SESSION["message"]="";
}
if (isset($_SESSION["messageReg"])) {
    $messageReg = $_SESSION["messageReg"];
    $_SESSION["messageReg"]="";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>AirLines-Login-Register</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_italic_600.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_italic_400.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/ie6_script_other.js"></script>
<script type="text/javascript" src="js/html5.js"></script>
<![endif]-->
</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="body1">
  <div class="main">
      <?php
      require_once  "partial/header.php";
      ?>
  </div>
</div>
<div class="main">
  <div id="banner">
    <div class="text1"> COMFORT<span>Guaranteed</span>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    </div>
    <a href="#" class="button_top">Order Tickets Online</a></div>
</div>
<div class="main">
  <section id="content">
    <article class="col1">
      <div class="pad_1">
        <h2>Login Form</h2>
        <form id="form_1" action="login.php" method="post">
          <div class="wrapper"> Username:
            <div class="bg">
              <input type="text" name="txtUsername" class="input input1" value="Enter Username" onBlur="if(this.value=='') this.value='Enter Username'" onFocus="if(this.value =='Enter Username' ) this.value=''">
            </div>
          </div>
          <div class="wrapper"> Password:
            <div class="bg">
              <input type="password" name="txtPassword"  class="input input1" value="Enter Password" onBlur="if(this.value=='') this.value='Enter Password'" onFocus="if(this.value =='Enter Password' ) this.value=''">
            </div>
          </div>
          <div class="wrapper">
            <div class="bg left">
              <input type="submit" name="btnLogin" class="button2" value="Login...!" />
            </div>
          </div>
          <p>
              <?php
              echo $message;
              ?></p>

        </form>
          <?php
          if (isset($_POST["btnLogin"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
              $txtUsername = $_POST["txtUsername"];
              $txtPassword= $_POST["txtPassword"];
              $db = new Database();
              $conn = $db->getConnection();
              //check passenger login
              $stmt = $conn->prepare("SELECT * FROM passenger where username=? and password =?");
              $stmt->bind_param("ss",$txtUsername,$txtPassword);
              $stmt->execute();
              $result = $stmt->get_result();
              $row = $result->fetch_assoc();

              //check admin login
              $stmtAdmin = $conn->prepare("SELECT * FROM admins where username=? and password =?");
              $stmtAdmin->bind_param("ss",$txtUsername,$txtPassword);
              $stmtAdmin->execute();
              $resultAdmin = $stmtAdmin->get_result();
              $rowAdmin = $resultAdmin->fetch_assoc();

              if ($result->num_rows > 0){
                  $_SESSION["username"] = $txtUsername ;
                  $_SESSION["userType"] = "passenger";
                  $_SESSION["id"] = $row["pid"];
                  $_SESSION["message"] = "";
                  echo "<script>window.location.href = 'index.php';</script>";
                  exit();
              }
              else if ($resultAdmin->num_rows > 0 ){
                  $_SESSION["username"] = $txtUsername ;
                  $_SESSION["userType"] = "admin";
                  $_SESSION["id"] = $rowAdmin["pid"];
                  $_SESSION["message"] = "";
                  echo "<script>window.location.href = 'index.php';</script>";
              }
              else {
                  unset($_SESSION["username"]);
                  unset($_SESSION["userType"]);
                  unset($_SESSION["id"]);
                  $_SESSION["message"] = "Invalid Username or Password";
                  echo "<script>window.location.href = 'login.php';</script>";
              }
          }
          ?>
      </div>
    </article>
    <article class="col2 pad_left1">
      <h2>Register Form</h2>
      <form id="form_2" action="login.php" method="post">
        <div class="wrapper"> Username and Password:
          <div class="bg">
            <input type="text" name="txtUsernameReg" class="input input1" style="background: lightyellow" value="Enter Username" onBlur="if(this.value=='') this.value='Enter Username'" onFocus="if(this.value =='Enter Username' ) this.value=''">
            <input type="password" name="txtPasswordReg" style="background: lightgoldenrodyellow" class="input input1" value="Enter Password" onBlur="if(this.value=='') this.value='Enter Password'" onFocus="if(this.value =='Enter Password' ) this.value=''">
          </div>
        </div>
        <div class="wrapper"> SurName And Name:
          <div class="bg">
            <input type="text" name="txtSurName" style="background: lightgoldenrodyellow" class="input input1" value="Enter SurName" onBlur="if(this.value=='') this.value='Enter SurName'" onFocus="if(this.value =='Enter SurName' ) this.value=''">
            <input type="text" name="txtName" style="background: lightgoldenrodyellow" class="input input1" value="Enter Name" onBlur="if(this.value=='') this.value='Enter Name'" onFocus="if(this.value =='Enter Name' ) this.value=''">
          </div>
        </div>
        <div class="wrapper"> Phone and Address:
          <div class="bg">
            <input type="text" name="txtPhone" style="background: lightgoldenrodyellow" class="input input1" value="Enter Phone" onBlur="if(this.value=='') this.value='Enter Phone'" onFocus="if(this.value =='Enter Phone' ) this.value=''">
            <input type="text" name="txtAddress" style="background: lightgoldenrodyellow" class="input input1" value="Enter Address" onBlur="if(this.value=='') this.value='Enter Address'" onFocus="if(this.value =='Enter Address' ) this.value=''">
          </div>
        </div>
        <div class="wrapper">
          <div class="bg left">
            <br/>
            <input type="submit" name="btnRegister" class="button2" value="Register...!" />
          </div>
        </div>
        <p> <?php echo $messageReg; ?></p>
      </form>
        <?php

        if (isset($_POST["btnRegister"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
            $txtUsernameReg = $_POST["txtUsernameReg"];
            $txtPasswordReg= $_POST["txtPasswordReg"];
            $txtSurName = $_POST["txtSurName"];
            $txtName= $_POST["txtName"];
            $txtPhone = $_POST["txtPhone"];
            $txtAddress= $_POST["txtAddress"];
            if (empty($txtUsernameReg) || empty($txtPasswordReg)||
            empty($txtSurName) ||  empty($txtName) || empty($txtPhone) || empty($txtAddress)){
                $_SESSION["messageReg"] = "Please fill all data";
                echo "<script>window.location.href = 'login.php';</script>";
            }
            $db = new Database();
            $conn = $db->getConnection();
            //check passenger login
            $stmt = $conn->prepare("insert into passenger(`surname`, `name`, `phone`, `address`, `username`, `password`) values (?,?,?,?,?,?)");
            $stmt->bind_param("ssssss",$txtSurName,$txtName,$txtPhone,$txtAddress,$txtUsernameReg,$txtPasswordReg);
            $stmt->execute();
            $_SESSION["messageReg"] = "you registered successfully";
            echo "<script>window.location.href = 'login.php';</script>";

        }
        ?>
    </article>
  </section>
</div>
<div class="body2">
  <div class="main">
      <?php
      require_once  "partial/footer.php";
      ?>
  </div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>