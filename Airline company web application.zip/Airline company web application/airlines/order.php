<?php
session_start();
include "db.php";

if (isset($_POST["btnOrder"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $id= $_POST["txtFlightID"];
    $quantity= $_POST["txtQuantity"];
    $idPassenger= $_SESSION["id"];
    if (!isset($_SESSION["id"])){
        $_SESSION["message"] = "please login first";
        echo "<script>window.location.href = 'index.php';</script>";
        exit();
    }
    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("insert into buy(flightnumber,pid,quantity) values (?,?,?)");
    $stmt->bind_param("ddd",$id,$idPassenger,$quantity);
    $stmt->execute();

    $_SESSION["message"] = "Order Received Successfully";
    echo "<script>window.location.href = 'index.php';</script>";

}
?>