<?php
session_start();
include "db.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Passenger Report</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all">
    <script type="text/javascript" src="js/jquery-1.4.2.js" ></script>
    <script type="text/javascript" src="js/cufon-yui.js"></script>
    <script type="text/javascript" src="js/cufon-replace.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_italic_600.font.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_italic_400.font.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/ie6_script_other.js"></script>
    <script type="text/javascript" src="js/html5.js"></script>
    <![endif]-->
</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="body1">
    <div class="main">
        <?php
        require_once  "partial/header.php";
        ?>
    </div>
</div>
<div class="main">
    <div id="banner">
        <div class="text1"> COMFORT<span>Guaranteed</span>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
        <a href="#" class="button_top">Order Tickets Online</a></div>
</div>
<div class="main">
    <section id="content">
        <article class="col1">
            <div class="pad_1">
                <h2>Information Form</h2>
                <form id="form_1" action="passengerreport.php" method="get">
                    <div class="wrapper"> FlightNumber:
                        <div class="bg">
                            <input type="text" name="flightNumber" class="input input1" />
                        </div>
                    </div>
                    <div class="wrapper">
                        <div class="bg left">
                            <input type="submit" class="button2" value="Search" />
                        </div>
                    </div>
                </form>
            </div>
        </article>
        <article class="col2 pad_left1">
            <h2>Information Form</h2>
            <form id="form_2" action="#" method="post">
                <div class="marker">
                    <div class="wrapper">
                        <p class="pad_bot2"><strong>All Data Information</strong></p>
                        <p class="pad_bot2">
                        <table>
                            <tr>
                                <td>
                                    Flight Number
                                </td>
                                <td>
                                    Origin
                                </td>
                                <td>
                                    Dest
                                </td>
                                <td>
                                    Price
                                </td>
                                <td>
                                    Quantity
                                </td>
                                <td>
                                    Airplane
                                </td>
                                <td>
                                    Pilot
                                </td>
                                <td>
                                    Passenger
                                </td>
                                <td>
                                    Phone
                                </td>
                            </tr>
                            <?php
                            $db = new Database();
                            $conn= $db->getConnection();
                            $date = new DateTime();
                            $sqlBase ="SELECT trip.*,buy.*,airplane.model as airplane , pilot.name as pilot,passenger.name as passenger , passenger.phone from buy,trip,airplane,passenger,pilot where trip.flightnumber = buy.flightnumber and trip.pilotid = pilot.pid and trip.numser = airplane.numser and passenger.pid = buy.pid";
                            $stmt = $conn->prepare($sqlBase);
                            if (isset($_GET["flightNumber"]) && empty($_GET["flightNumber"]) == false){
                                $sqlBase .= " and buy.flightnumber = ?  and buy.pid=?";
                                $stmt = $conn->prepare($sqlBase);
                                $fn=$_GET["flightNumber"];
                                $ps = $_SESSION["id"];
                                $stmt->bind_param("dd",$fn,$ps);
                            }
                            else {
                                $sqlBase .= " and buy.pid=?";
                                $stmt = $conn->prepare($sqlBase);
                                $ps = $_SESSION["id"];
                                $stmt->bind_param("d",$ps);
                            }
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $color = 0 ;
                            while ($row = $result->fetch_assoc()){
                                echo "<tr>
                    <td class=\"text-center\">{$row["flightnumber"]}<br /></td>
                    <td class=\"text-center\">{$row["origin"]}<br /></td>
                    <td class=\"text-center\">{$row["dest"]}<br /></td>
                    <td class=\"text-center\">{$row["price"]}<br /></td>
                    <td class=\"text-center\">{$row["quantity"]}<br /></td>
                    <td class=\"text-center\">{$row["airplane"]}<br /></td>
                    <td class=\"text-center\">{$row["pilot"]}<br /></td>
                    <td class=\"text-center\">{$row["passenger"]}<br /></td>
                    <td class=\"text-center\">{$row["phone"]}<br /></td>
                  </tr>";
                            }
                            ?>
                        </table>
                    </div>

                </div>
            </form>
        </article>
    </section>
</div>
<div class="body2">
    <div class="main">
        <?php
        require_once  "partial/footer.php";
        ?>
    </div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>