<?php
session_start();
include "db.php";

if (isset($_POST["btnAdd"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $id= $_POST["txtBuildNumber"];
    $model= $_POST["txtModel"];
    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("insert into airplane(buildnumber,model) values (?,?)");
    $stmt->bind_param("ds",$id,$model);
    $stmt->execute();
    $_SESSION["message"] = "Added Data Successfully";
    echo "<script>window.location.href = 'airplane.php';</script>";
}
if (isset($_POST["btnEdit"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $build= $_POST["txtBuildNumber"];
    $model= $_POST["txtModel"];
    $id = $_POST["txtID"];

    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("update airplane set buildnumber=?,model=? where numser = ?");
    $stmt->bind_param("dsd",$build,$model,$id);
    $stmt->execute();
    $_SESSION["message"] = "Update Data Successfully";
    echo "<script>window.location.href = 'airplane.php';</script>";
}
if (isset($_POST["btnDelete"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $id = $_POST["txtID"];
    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("delete from  airplane where numser = ?");
    $stmt->bind_param("d",$id);
    $stmt->execute();
    $_SESSION["message"] = "Delete Data Successfully";
    echo "<script>window.location.href = 'airplane.php';</script>";
}
?>