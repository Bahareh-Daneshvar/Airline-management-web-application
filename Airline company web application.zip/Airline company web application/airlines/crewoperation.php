<?php
session_start();
include "db.php";

if (isset($_POST["btnAdd"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $id= $_POST["txtEmpnum"];
    $surname= $_POST["txtSurName"];
    $name= $_POST["txtName"];
    $phone= $_POST["txtPhone"];
    $salary= $_POST["txtSalary"];
    $address= $_POST["txtAddress"];
    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("insert into Crew(surname,name,phone,salary,address) values (?,?,?,?,?)");
    $stmt->bind_param("sssds",$surname,$name,$phone,$salary,$address);
    $stmt->execute();
    $_SESSION["message"] = "Added Data Successfully";
    echo "<script>window.location.href = 'crew.php';</script>";
}
if (isset($_POST["btnEdit"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $id= $_POST["txtEmpnum"];
    $surname= $_POST["txtSurName"];
    $name= $_POST["txtName"];
    $phone= $_POST["txtPhone"];
    $salary= $_POST["txtSalary"];
    $address= $_POST["txtAddress"];

    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("update crew set surname=?,name=?,phone=?,salary=?,address=? where empnum = ?");
    $stmt->bind_param("sssdsd",$surname,$name,$phone,$salary,$address,$id);
    $stmt->execute();
    $_SESSION["message"] = "Update Data Successfully";
    echo "<script>window.location.href = 'crew.php';</script>";
}
if (isset($_POST["btnDelete"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $id = $_POST["txtEmpnum"];
    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("delete from crew where empnum = ?");
    $stmt->bind_param("d",$id);
    $stmt->execute();
    $_SESSION["message"] = "Delete Data Successfully";
    echo "<script>window.location.href = 'crew.php';</script>";
}
?>