<?php
session_start();
include "db.php";
$message= "";
$id = -1;
$origin= "";
$dest = "" ;
$datetime ="";
$pilotid = 0;
$numser = 0 ;
$price = 0;
if (isset($_SESSION["message"])) {
    $message = $_SESSION["message"];
    $_SESSION["message"]="";

}
if (isset($_GET["id"])){
    $db = new Database();
    $conn= $db->getConnection();
    $date = new DateTime();
    $id  =$_GET["id"];
    $stmt = $conn->prepare("SELECT * FROM trip where flightnumber = ? ");
    $stmt->bind_param("d",$id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $origin = $row["origin"];
    $dest = $row["dest"];
    $datetime = $row["datetime"];
    $pilotid = $row["pilotid"];
    $numser = $row["numser"];
    $price = $row["price"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Trip</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all">
    <script type="text/javascript" src="js/jquery-1.4.2.js" ></script>
    <script type="text/javascript" src="js/cufon-yui.js"></script>
    <script type="text/javascript" src="js/cufon-replace.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_italic_600.font.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_italic_400.font.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/ie6_script_other.js"></script>
    <script type="text/javascript" src="js/html5.js"></script>
    <![endif]-->
    <style>
        table,tr,td{
            font-size:10pt;
        }
    </style>
</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="body1">
    <div class="main">
        <?php
        require_once  "partial/header.php";
        ?>
    </div>
</div>
<div class="main">
    <div id="banner">
        <div class="text1"> COMFORT<span>Guaranteed</span>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
        <a href="#" class="button_top">Order Tickets Online</a></div>
</div>
<div class="main">
    <section id="content">
        <article class="col1">
            <div class="pad_1">
                <h2>Information Form</h2>
                <form id="form_1" action="tripoperation.php" method="post">
                    <div class="wrapper"> FlightNumber:
                        <div class="bg">
                            <input type="text" name="txtFlightNumber"  class="input input1" value="<?php echo $id; ?>" onBlur="if(this.value=='') this.value='Enter FlightNumber'" onFocus="if(this.value =='Enter FlightNumber' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> Origin:
                        <div class="bg">
                            <input type="text" name="txtOrigin" class="input input1" value="<?php echo $origin; ?>" onBlur="if(this.value=='') this.value='Enter Origin'" onFocus="if(this.value =='Enter Origin' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> Dest:
                        <div class="bg">
                            <input type="text" name="txtDest" class="input input1" value="<?php echo $dest; ?>" onBlur="if(this.value=='') this.value='Enter Dest'" onFocus="if(this.value =='Enter Dest' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> DateTime:
                        <div class="bg">
                            <input type="text" name="txtDateTime" class="input input1" value="<?php echo $datetime; ?>" onBlur="if(this.value=='') this.value='Enter DateTime'" onFocus="if(this.value =='Enter DateTime' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> Price:
                        <div class="bg">
                            <input type="text" name="txtPrice" class="input input1" value="<?php echo $price; ?>" onBlur="if(this.value=='') this.value='Enter Price'" onFocus="if(this.value =='Enter Price' ) this.value=''">
                        </div>
                    </div>
                    <div class="wrapper"> Select Pilot:
                        <div class="bg">

                            <select name="idPilot">
                                <?php
                                $db = new Database();
                                $conn= $db->getConnection();
                                $date = new DateTime();
                                $id  =$_GET["id"];
                                $stmt = $conn->prepare("SELECT * FROM pilot");
                                $stmt->execute();
                                $result = $stmt->get_result();
                                while($row = $result->fetch_assoc()){
                                    echo " <option value=\"{$row["pid"]}\">{$row["name"]}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="wrapper"> Select AirPlane:
                        <div class="bg">
                            <select name="idAirplane">
                                <?php
                                $db = new Database();
                                $conn= $db->getConnection();
                                $date = new DateTime();
                                $id  =$_GET["id"];
                                $stmt = $conn->prepare("SELECT * FROM airplane");
                                $stmt->execute();
                                $result = $stmt->get_result();
                                while($row = $result->fetch_assoc()){
                                  echo " <option value=\"{$row["numser"]}\">{$row["model"]}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="wrapper">
                        <div class="bg left">
                            <input type="submit" name="btnAdd" class="button2" value="Add" />
                            <input type="submit" name="btnEdit" class="button2" value="Edit" />

                        </div>
                        <input type="submit" style="width: 100%;" name="btnDelete" class="button2" value="Delete" />
                </form>
                        <hr/>
                        <form id="form_2" action="trip.php" method="get">
                            <div class="wrapper"> From Date:
                                <div class="bg">
                                    <input type="text" name="txtFDate" class="input input1" />
                                </div>
                            </div>
                            <div class="wrapper"> TO DateTime:
                                <div class="bg">
                                    <input type="text" name="txtTDate" class="input input1" />
                                </div>
                            </div>
                            <input type="submit" name="Search" class="button2" value="Search" />
                        </form>
                    </div>
                    <p> <?php echo $message;   ?></p>


            </div>
        </article>
        <article class="col2 pad_left1">
            <h2>Information Form</h2>
            <form id="form_2" action="#" method="post">
                <div class="marker">
                    <div class="wrapper">
                        <p class="pad_bot2"><strong>All Trip Information</strong></p>
                        <p class="pad_bot2">
                        <table>
                            <tr>
                                <td>
                                    FlightNumber
                                </td>
                                <td>
                                    Origin
                                </td>
                                <td>
                                    Dest
                                </td>
                                <td>
                                    DateTime
                                </td>
                                <td>
                                    Price
                                </td>
                                <td>
                                    PilotName
                                </td>
                                <td>
                                    AirPlane
                                </td>
                                <td>
                                    Operations
                                </td>
                            </tr>
                            <?php
                            $db = new Database();
                            $conn= $db->getConnection();
                            $date = new DateTime();
                            $sqlBase="SELECT trip.*,airplane.model  as airplane , airplane.buildnumber as build , pilot.name as pilot FROM trip,airplane,pilot where trip.pilotid = pilot.pid and trip.numser = airplane.numser ";
                            $stmt = $conn->prepare($sqlBase);
                            if (isset($_GET["txtFDate"]) && empty($_GET["txtTDate"]) == false){
                                $sqlBase .= " and trip.datetime between ? and ?";
                                $stmt = $conn->prepare($sqlBase);
                                $fDate=$_GET["txtFDate"];
                                $tDate=$_GET["txtTDate"];
                                $stmt->bind_param("ss",$fDate,$tDate);
                            }
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $color = 0 ;
                            while ($row = $result->fetch_assoc()){
                                if (isset($_GET["id"])){$color=$_GET["id"];}
                                $air = $row["airplane"] . $row["build"];

                                if ($color == $row["flightnumber"]){
                                    echo "<tr style='background: red;'>
                    <td class=\"text-center\">{$row["flightnumber"]}<br /></td>
                    <td class=\"text-center\">{$row["origin"]}<br /></td>
                    <td class=\"text-center\">{$row["dest"]}<br /></td>
                    <td class=\"text-center\">{$row["datetime"]}<br /></td>
                    <td class=\"text-center\">{$row["price"]}<br /></td>
                    <td class=\"text-center\">{$row["pilot"]}<br /></td>
                    <td class=\"text-center\">{$air}<br /></td>
                    <td class=\"text-right\"><a href='trip.php?id={$row["flightnumber"]}'>Select</a> </td>
                  </tr>";
                                }
                                else {
                                    echo "<tr>
                    <td class=\"text-center\">{$row["flightnumber"]}<br /></td>
                    <td class=\"text-center\">{$row["origin"]}<br /></td>
                    <td class=\"text-center\">{$row["dest"]}<br /></td>
                    <td class=\"text-center\">{$row["datetime"]}<br /></td>
                    <td class=\"text-center\">{$row["price"]}<br /></td>
                    <td class=\"text-center\">{$row["pilot"]}<br /></td>
                    <td class=\"text-center\">{$air}<br /></td>
                    <td class=\"text-right\"><a href='trip.php?id={$row["flightnumber"]}'>Select</a> </td>
                  </tr>";
                                }

                            }
                            ?>
                        </table>
                    </div>

                </div>
            </form>
        </article>
    </section>
</div>
<div class="body2">
    <div class="main">
        <?php
        require_once  "partial/footer.php";
        ?>
    </div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>