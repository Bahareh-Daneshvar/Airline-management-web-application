<?php
session_start();
include "db.php";
$message = "";
if (isset($_SESSION["message"])){
    $message = $_SESSION["message"];
    $_SESSION["message"]="";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>AirLines</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all">
    <script type="text/javascript" src="js/jquery-1.4.2.js" ></script>
    <script type="text/javascript" src="js/cufon-yui.js"></script>
    <script type="text/javascript" src="js/cufon-replace.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_italic_600.font.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_italic_400.font.js"></script>
    <script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/ie6_script_other.js"></script>
    <script type="text/javascript" src="js/html5.js"></script>
    <![endif]-->
</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="body1">
    <div class="main">
        <?php
        require_once  "partial/header.php";
        ?>
    </div>
</div>
<div class="main">
    <div id="banner">
        <div class="text1"> COMFORT<span>Guaranteed</span>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
        <a href="#" class="button_top">Order Tickets Online</a></div>
</div>
<div class="main">
    <section id="content">
        <article class="col1">
            <div class="pad_1">
                <h2>Your Flight Planner</h2>
                <form id="form_1" action="index.php" method="get">
                    <div class="wrapper"> Origin:
                        <div class="bg">
                            <input type="text" name="Origin" class="input input1" value="" />
                        </div>
                    </div>
                    <div class="wrapper"> Dest:
                        <div class="bg">
                            <input type="text" name="Dest" class="input input1" value="" />
                        </div>
                    </div>
                    <div class="wrapper">
                        <div class="bg left">
                            <input type="submit" class="button2" value="Search...!" />
                        </div>
                    </div>

                    <h2>Recent News</h2>
                    <p class="under"><a href="#" class="link1">Nemo enim ipsam voluptatem quia</a><br>
                        November 5, 2010</p>
                    <p class="under"><a href="#" class="link1">Voluptas aspernatur autoditaut fjugit</a><br>
                        November 1, 2010</p>
                    <p><a href="#" class="link1">Sed quia consequuntur magni</a><br>
                        October 23, 2010</p>
            </div>
        </article>
        <article class="col2 pad_left1">
            <h2>Welcome to our Website! Please See All Flight Plan</h2>
            <p class="color1">Lorem ....</p>
            <p class="color1">Lorem ....</p>
            <div class="marker">
                <div class="wrapper">
                    <p class="pad_bot2"><strong>All Flight Plans</strong></p>
                    <p class="pad_bot2">
                    <form id="form_2" action="index.php" method="get">

                        <table>
                            <tr>
                                <td>
                                    Flight Number
                                </td>
                                <td>
                                    Origin
                                </td>
                                <td>
                                    Dest
                                </td>
                                <td>
                                    DateTime
                                </td>
                                <td>
                                    AirPlane
                                </td>
                                <td>
                                    Operations
                                </td>
                            </tr>
                            <?php
                            $db = new Database();
                            $conn= $db->getConnection();
                            $origin=false ;
                            $dest=false;
                            $sql = "SELECT trip.*, airplane.model as air FROM trip,airplane where airplane.numser = trip.numser and  trip.datetime > NOW()";
                            if (isset($_GET["Origin"]) && empty($_GET["Origin"]) == false){
                                $sql .= " and trip.Origin=?";
                                $origin= true;
                            }
                            if (isset($_GET["Dest"]) && empty($_GET["Dest"]) == false){
                                $sql .= " and trip.Dest=?";
                                $dest= true;
                            }
                            $stmt = $conn->prepare($sql);
                            if ($origin && $dest){
                                $stmt->bind_param("ss",$_GET["Origin"],$_GET["Dest"]);
                                echo "test";
                            }
                            if ($origin && $dest == false){
                                $stmt->bind_param("s",$_GET["Origin"]);

                            }
                            if ($dest && $origin == false){
                                $stmt->bind_param("s",$_GET["Dest"]);
                            }
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $color = 0 ;
                            while ($row = $result->fetch_assoc()){
                                if (isset($_GET["id"])){$color=$_GET["id"];}
                                if ($color == $row["flightnumber"]){
                                    echo "<tr style='background: red;'>
                    <td class=\"text-center\">{$row["flightnumber"]}<br /></td>
                    <td class=\"text-center\">{$row["origin"]}<br /></td>
                    <td class=\"text-center\">{$row["dest"]}<br /></td>
                    <td class=\"text-right\">{$row["datetime"]} </td>
                    <td class=\"text-right\">{$row["air"]} </td>
                    <td class=\"text-right\"><a href='index.php?id={$row["flightnumber"]}'>Select</a> </td>
                    
                  </tr>";
                                }
                                else {
                                    echo "<tr>
                    <td class=\"text-center\">{$row["flightnumber"]}<br /></td>
                    <td class=\"text-center\">{$row["origin"]}<br /></td>
                    <td class=\"text-center\">{$row["dest"]}<br /></td>
                    <td class=\"text-right\">{$row["datetime"]} </td>
                    <td class=\"text-right\">{$row["air"]} </td>
                    <td class=\"text-right\"><a href='index.php?id={$row["flightnumber"]}'>Select</a> </td>
                    
                  </tr>";
                                }

                            }
                            ?>

                        </table>
                    </form>
                </div>

            </div>
            <form id="form_3" action="order.php" method="post">

                <div class="wrapper">
                    <p><br/>Passenger(s):</p>
                    <div class="bg left">
                        <input type="text" name="txtQuantity" class="input input2" style="background: lightyellow" value="# passengers" onBlur="if(this.value=='') this.value='# passengers'" onFocus="if(this.value =='# passengers' ) this.value=''">
                    </div>
                    <div class="bg left">
                        <input type="text" readonly name="txtFlightID" value="<?php echo isset($_GET["id"])?  $_GET["id"] : ""; ?>" class="input input2" />
                    </div>
                    <input type="submit" name="btnOrder"  value="Order...!" />
                </div>
                <p>
                    <?php
                    echo $message;
                    ?></p>
        </article>

        </form>

    </section>
</div>
<div class="body2">
    <div class="main">
        <?php
        require_once  "partial/footer.php";
        ?>
    </div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>