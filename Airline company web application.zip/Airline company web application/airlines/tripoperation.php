<?php
session_start();
include "db.php";

if (isset($_POST["btnAdd"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $txtFlightNumber= $_POST["txtFlightNumber"];
    $txtOrigin= $_POST["txtOrigin"];
    $txtDest= $_POST["txtDest"];
    $txtDateTime= $_POST["txtDateTime"];
    $txtPrice= $_POST["txtPrice"];
    $idPilot= $_POST["idPilot"];
    $idAirplane= $_POST["idAirplane"];
    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("insert into trip(flightnumber,origin,dest,datetime,price,pilotid,numser) values (?,?,?,?,?,?,?)");
    $stmt->bind_param("dsssddd",$txtFlightNumber,$txtOrigin,$txtDest,$txtDateTime,$txtPrice,$idPilot,$idAirplane);
    $stmt->execute();
    $_SESSION["message"] = "Added Data Successfully";
    echo "<script>window.location.href = 'trip.php';</script>";
}
if (isset($_POST["btnEdit"]) && $_SERVER["REQUEST_METHOD"] == "POST") {

    $txtFlightNumber= $_POST["txtFlightNumber"];
    $txtOrigin= $_POST["txtOrigin"];
    $txtDest= $_POST["txtDest"];
    $txtDateTime= $_POST["txtDateTime"];
    $txtPrice= $_POST["txtPrice"];
    $idPilot= $_POST["idPilot"];
    $idAirplane= $_POST["idAirplane"];
    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("update trip set origin=?,dest=?,datetime=?,price=?,pilotid=?,numser=? where flightnumber=?");
    $stmt->bind_param("sssdddd",$txtOrigin,$txtDest,$txtDateTime,$txtPrice,$idPilot,$idAirplane,$txtFlightNumber);
    $stmt->execute();
    $_SESSION["message"] = "Update Data Successfully";
    echo "<script>window.location.href = 'trip.php';</script>";

}
if (isset($_POST["btnDelete"]) && $_SERVER["REQUEST_METHOD"] == "POST"){
    $id = $_POST["txtFlightNumber"];
    $db = new Database();
    $conn= $db->getConnection();
    $stmt = $conn->prepare("delete from trip where flightnumber = ?");
    $stmt->bind_param("d",$id);
    $stmt->execute();
    $_SESSION["message"] = "Delete Data Successfully";
    echo "<script>window.location.href = 'trip.php';</script>";
}
?>