-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2022 at 07:14 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airplanecompanydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `pid` int(11) NOT NULL,
  `surname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_persian_ci NOT NULL,
  `address` text COLLATE utf8_persian_ci NOT NULL,
  `username` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`pid`, `surname`, `name`, `phone`, `address`, `username`, `password`) VALUES
(1, 'bahare', 'bahare', '444484845', 'london', 'bahar', '123');

-- --------------------------------------------------------

--
-- Table structure for table `airplane`
--

CREATE TABLE `airplane` (
  `numser` int(11) NOT NULL,
  `model` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `buildnumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `airplane`
--

INSERT INTO `airplane` (`numser`, `model`, `buildnumber`) VALUES
(1, 'boeing', 705),
(6, 'Boing8080', 400),
(7, 'Boing', 400);

-- --------------------------------------------------------

--
-- Table structure for table `buy`
--

CREATE TABLE `buy` (
  `id` int(11) NOT NULL,
  `flightnumber` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `buy`
--

INSERT INTO `buy` (`id`, `flightnumber`, `pid`, `quantity`) VALUES
(19, 100, 1, 2),
(21, 2560, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `crew`
--

CREATE TABLE `crew` (
  `empnum` int(11) NOT NULL,
  `surname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_persian_ci NOT NULL,
  `address` text COLLATE utf8_persian_ci NOT NULL,
  `salary` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `crewlist`
--

CREATE TABLE `crewlist` (
  `id` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `flightnumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `middlecities`
--

CREATE TABLE `middlecities` (
  `id` int(11) NOT NULL,
  `flightnumber` int(11) NOT NULL,
  `mcid` int(11) NOT NULL,
  `arrtime` time NOT NULL,
  `deptime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `middlecity`
--

CREATE TABLE `middlecity` (
  `MID` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `surname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_persian_ci NOT NULL,
  `address` text COLLATE utf8_persian_ci NOT NULL,
  `username` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `pid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`surname`, `name`, `phone`, `address`, `username`, `password`, `pid`) VALUES
('test', 'test', '54484', 'tfddd', 'test', 'test', 1),
('sara', 'sara', '484844', 'ggsdf', 'sara', 'sara', 3),
('hasan', 'hasani', '44848454', 'london', 'hasan', '123', 4);

-- --------------------------------------------------------

--
-- Table structure for table `pilot`
--

CREATE TABLE `pilot` (
  `surname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_persian_ci NOT NULL,
  `address` text COLLATE utf8_persian_ci NOT NULL,
  `salary` int(11) NOT NULL,
  `airplanes` text COLLATE utf8_persian_ci NOT NULL,
  `pid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `pilot`
--

INSERT INTO `pilot` (`surname`, `name`, `phone`, `address`, `salary`, `airplanes`, `pid`) VALUES
('ahmadiiii', 'hossein', '1484844', 'fffds', 14000, 'boing 808-boing909', 1),
('samani', 'saman', '4411884844', 'london', 8000, 'boing 707,boing808', 2),
('Mohammad', 'vv', '12447441', 'tejfd', 1585, 'boing 708,boing899', 3);

-- --------------------------------------------------------

--
-- Table structure for table `trip`
--

CREATE TABLE `trip` (
  `flightnumber` int(11) NOT NULL,
  `origin` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `dest` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `datetime` datetime NOT NULL,
  `pilotid` int(11) NOT NULL,
  `numser` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `trip`
--

INSERT INTO `trip` (`flightnumber`, `origin`, `dest`, `datetime`, `pilotid`, `numser`, `price`) VALUES
(100, 'test', 'test', '2023-12-25 11:54:21', 1, 1, 140),
(2560, 'london', 'paris', '2023-12-25 12:54:21', 1, 1, 700),
(4430, 'london', 'paris', '2023-12-25 11:54:21', 1, 6, 400);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `airplane`
--
ALTER TABLE `airplane`
  ADD PRIMARY KEY (`numser`);

--
-- Indexes for table `buy`
--
ALTER TABLE `buy`
  ADD PRIMARY KEY (`id`),
  ADD KEY `flightnumber` (`flightnumber`);

--
-- Indexes for table `crew`
--
ALTER TABLE `crew`
  ADD PRIMARY KEY (`empnum`),
  ADD KEY `empnum` (`empnum`);

--
-- Indexes for table `crewlist`
--
ALTER TABLE `crewlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `cid` (`cid`),
  ADD KEY `flightnumber` (`flightnumber`);

--
-- Indexes for table `middlecities`
--
ALTER TABLE `middlecities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `flightnumber` (`flightnumber`),
  ADD KEY `mcid` (`mcid`);

--
-- Indexes for table `middlecity`
--
ALTER TABLE `middlecity`
  ADD PRIMARY KEY (`MID`),
  ADD KEY `MID` (`MID`);

--
-- Indexes for table `passenger`
--
ALTER TABLE `passenger`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `pilot`
--
ALTER TABLE `pilot`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `trip`
--
ALTER TABLE `trip`
  ADD PRIMARY KEY (`flightnumber`),
  ADD KEY `flightnumber` (`flightnumber`),
  ADD KEY `numser` (`numser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `airplane`
--
ALTER TABLE `airplane`
  MODIFY `numser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `buy`
--
ALTER TABLE `buy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `passenger`
--
ALTER TABLE `passenger`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pilot`
--
ALTER TABLE `pilot`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `crewlist`
--
ALTER TABLE `crewlist`
  ADD CONSTRAINT `crewlist_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `crew` (`empnum`),
  ADD CONSTRAINT `crewlist_ibfk_2` FOREIGN KEY (`flightnumber`) REFERENCES `trip` (`flightnumber`);

--
-- Constraints for table `middlecities`
--
ALTER TABLE `middlecities`
  ADD CONSTRAINT `middlecities_ibfk_1` FOREIGN KEY (`mcid`) REFERENCES `middlecity` (`MID`),
  ADD CONSTRAINT `middlecities_ibfk_2` FOREIGN KEY (`flightnumber`) REFERENCES `trip` (`flightnumber`);

--
-- Constraints for table `trip`
--
ALTER TABLE `trip`
  ADD CONSTRAINT `trip_ibfk_1` FOREIGN KEY (`pilotid`) REFERENCES `pilot` (`pid`),
  ADD CONSTRAINT `trip_ibfk_2` FOREIGN KEY (`numser`) REFERENCES `airplane` (`numser`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
